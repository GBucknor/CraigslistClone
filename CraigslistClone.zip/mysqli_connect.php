<?php
    define('DB_USER', 'root');
    define('DB_PASSWORD', '1234');
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'craigslist');
?>