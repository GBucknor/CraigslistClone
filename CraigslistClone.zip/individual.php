<!DOCTYPE html>
<html>
    <head>
        <title>craigslist - account log in</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        
        <!-- Craigslist Tab Icon -->
        <link rel="icon" href="Images/logo.png">
        
        <!-- CSS Files -->
        <link rel="stylesheet" href="CSS/Base.css" type="text/css">
    </head>
</html>